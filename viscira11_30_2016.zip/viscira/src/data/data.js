var jsonData = {
  "Aetna": {
    "name": "Aetna",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Dr. Robert McDonough",
        "parent": "Aetna",
        "influence": 3,
        "icon": "node.png"
      },
      {
        "name": "Lichtenfeld",
        "parent": "Aetna",
        "influence": 2,
        "icon": "node.png"
      }
    ]
  },
  "HOPA": {
    "name": "HOPA",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Niesha Griffith",
        "parent": "HOPA",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Scott Soefje",
        "parent": "HOPA",
        "influence": 3,
        "icon": "node.png"
      },
      {
        "name": "Raymond J. Muller",
        "parent": "HOPA",
        "influence": 3,
        "icon": "node.png"
      },
      {
        "name": "Edward Li",
        "parent": "HOPA",
        "influence": 3,
        "icon": "node.png"
      },
      {
        "name": "Sarah Scarpace",
        "parent": "HOPA",
        "influence": 3,
        "icon": "node.png"
      }
    ]
  },
  "eviti": {
    "name": "eviti",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Dr. Garrett R. Lynch",
        "parent": "eviti",
        "influence": 3,
        "icon": "node.png"
      },
      {
        "name": "Arlene Forastiere",
        "parent": "eviti",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "William Flood",
        "parent": "eviti",
        "influence": 4,
        "icon": "node.png"
      }
    ]
  },
  "Skin Cancer Foundation": {
    "name": "Skin Cancer Foundation",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Dr. Perry Robins",
        "parent": "Skin Cancer Foundation",
        "influence": 3,
        "icon": "node.png"
      }
    ]
  },
  "VIA": {
    "name": "VIA",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Dr. Peter G. Ellis",
        "parent": "VIA",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Dr. Leonard J. Appleman",
        "parent": "VIA",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Dr. Frederick R. Aronson",
        "parent": "VIA",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Dr. John M. Kirkwood",
        "parent": "VIA",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Dr. Leslie Fecher",
        "parent": "VIA",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Kathy Lokay",
        "parent": "VIA",
        "influence": 4,
        "icon": "node.png"
      }
    ]
  },
  "NCCN": {
    "name": "NCCN",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Dr. Christopher K. Bichakjian",
        "parent": "NCCN",
        "influence": 5,
        "icon": "node.png"
      },
      {
        "name": "Dr. Robert (Bob) W. Carlson",
        "parent": "NCCN",
        "influence": 5,
        "icon": "node.png"
      },
      {
        "name": "Kimberly (Brydges) C.Drager",
        "parent": "NCCN",
        "influence": null,
        "icon": "node.png"
      },
      {
        "name": "Kristina M. Gregory",
        "parent": "NCCN",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Lyn C. Fitzgerald",
        "parent": "NCCN",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Marian",
        "parent": "NCCN",
        "influence": null,
        "icon": "node.png"
      },
      {
        "name": "Christian Downs",
        "parent": "NCCN",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Dr. McClure",
        "parent": "NCCN",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Dr. Peter E. Clark",
        "parent": "NCCN",
        "influence": 5,
        "icon": "node.png"
      }
    ]
  },
  "Oncology Analytics": {
    "name": "Oncology Analytics",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Dr. Marc Fishman",
        "parent": "Oncology Analytics",
        "influence": 3,
        "icon": "node.png"
      },
      {
        "name": "Dr. William Hrushesky",
        "parent": "Oncology Analytics",
        "influence": 2,
        "icon": "node.png"
      }
    ]
  },
  "ASCO": {
    "name": "ASCO",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Ms. Deborah Kamin",
        "parent": "ASCO",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Dr. Cliff A.Hudis",
        "parent": "ASCO",
        "influence": 5,
        "icon": "node.png"
      },
      {
        "name": "Dr. Stephen S. Grubbs",
        "parent": "ASCO",
        "influence": null,
        "icon": "node.png"
      }
    ]
  },
  "Kaiser Permanente": {
    "name": "Kaiser Permanente",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Jay Rho",
        "parent": "Kaiser Permanente",
        "influence": 3,
        "icon": "node.png"
      },
      {
        "name": "Gary Besinque",
        "parent": "Kaiser Permanente",
        "influence": 2,
        "icon": "node.png"
      },
      {
        "name": "Karen Chin",
        "parent": "Kaiser Permanente",
        "influence": 2,
        "icon": "node.png"
      },
      {
        "name": "Samuel Lum",
        "parent": "Kaiser Permanente",
        "influence": 3,
        "icon": "node.png"
      }
    ]
  },
  "Merkelcell.org": {
    "name": "Merkelcell.org",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Dr. Paul Nghiem",
        "parent": "Merkelcell.org",
        "influence": 5,
        "icon": "node.png"
      }
    ]
  },
  "PAF/NPAF": {
    "name": "PAF/NPAF",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Al B. Benson",
        "parent": "PAF/NPAF",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Dr. Robert (Bob) Rifkin",
        "parent": "PAF/NPAF",
        "influence": 3,
        "icon": "node.png"
      },
      {
        "name": "Dr. Alan J.Balch",
        "parent": "PAF/NPAF",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Dennis A. Gastineau",
        "parent": "PAF/NPAF",
        "influence": 2,
        "icon": "node.png"
      },
      {
        "name": "Dr. F. Stewart Marc",
        "parent": "PAF/NPAF",
        "influence": null,
        "icon": "node.png"
      }
    ]
  },
  "McKesson-US Oncology": {
    "name": "McKesson-US Oncology",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Dr. Russ Hoverman",
        "parent": "McKesson-US Oncology",
        "influence": null,
        "icon": "node.png"
      },
      {
        "name": "Marcus Neubauer",
        "parent": "McKesson-US Oncology",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Dr. Michael Seiden",
        "parent": "McKesson-US Oncology",
        "influence": 4,
        "icon": "node.png"
      }
    ]
  },
  "Anthem": {
    "name": "Anthem",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Dr. Jennifer Malin",
        "parent": "Anthem",
        "influence": 5,
        "icon": "node.png"
      }
    ]
  },
  "New Century Health": {
    "name": "New Century Health",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Dr. Atul Dhir",
        "parent": "New Century Health",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Andrew Hertler",
        "parent": "New Century Health",
        "influence": 3,
        "icon": "node.png"
      }
    ]
  },
  "COA": {
    "name": "COA",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Ted Okon",
        "parent": "COA",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Vassos",
        "parent": "COA",
        "influence": 3,
        "icon": "node.png"
      },
      {
        "name": "Mary Kruczynski",
        "parent": "COA",
        "influence": 3,
        "icon": "node.png"
      }
    ]
  },
  "Humana": {
    "name": "Humana",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Dr. Bryan Loy",
        "parent": "Humana",
        "influence": 4,
        "icon": "node.png"
      },
      {
        "name": "Charles Stemple",
        "parent": "Humana",
        "influence": 3,
        "icon": "node.png"
      }
    ]
  },
  "Bladder Cancer Advocacy Network": {
    "name": "Bladder Cancer Advocacy Network",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Diane Zipursky Quale",
        "parent": "Bladder Cancer Advocacy Network",
        "influence": 4,
        "icon": "node.png"
      }
    ]
  },
  "American Society of Clinical Oncology (ASCO)": {
    "name": "American Society of Clinical Oncology (ASCO)",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Dr. Richard L. Schilsky",
        "parent": "American Society of Clinical Oncology (ASCO)",
        "influence": 4,
        "icon": "node.png"
      }
    ]
  },
  "UnitedHealthcare": {
    "name": "UnitedHealthcare",
    "parent": "null",
    "type": null,
    "children": [
      {
        "name": "Dr. Lee Newcomer",
        "parent": "UnitedHealthcare",
        "influence": 5,
        "icon": "node.png"
      }
    ]
  }
}