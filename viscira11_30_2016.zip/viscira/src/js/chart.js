(function(){
    if (typeof visciraApp === 'undefined') {
        visciraApp = {
            "chart":{
                     "init":function(data){}
            }
        };
    }
})(); 

visciraApp.chart.searchNodes = function(){
 var searchText = document.getElementById('searchText').value;
 console.log(visciraApp.chart.originalData);
 var newDataObject = {};
  if(searchText){
    _.each(visciraApp.chart.originalData, function(record, key){
          if(key.indexOf(searchText) !== -1 ){
            newDataObject[key] = record;
        }
    });
     visciraApp.chart.init(newDataObject);
  }else{
     visciraApp.chart.init(visciraApp.chart.originalData);
  }  
};

visciraApp.chart.reset = function(){
  visciraApp.chart.init(visciraApp.chart.originalData);
}

visciraApp.chart.firstTimeRendered = false;
visciraApp.chart.originalData = {};

visciraApp.chart.init = function(data){
    var dataObj = {};
    if(typeof data == 'string'){
         dataObj = JSON.parse(dataStr);
    }else if (typeof data === 'object'){
            dataObj = data;
    }
    //Set Original Data for reference first time.
    if(!visciraApp.chart.firstTimeRendered){
        visciraApp.chart.firstTimeRendered = true;
        visciraApp.chart.originalData  = dataObj;
    }

    var settings = {
            "width":1200,
            "height":1150,
            "margin":{
                    "top":10,
                    "bottom":10,
                    "left":10,
                    "right":0,
                    "labelMargin":10
                }
    };
    console.log( ' data Object ', dataObj);
    
    visciraApp.chart.draw(dataObj, settings);
};

visciraApp.chart.draw = function(dataObj, settings){
    var element = document.getElementById('graph');
    d3.select(element).selectAll("*").remove();
    var svgHeight = settings.height+settings.margin.top+settings.margin.bottom;

    var svgWidth =  settings.width - settings.margin.left - settings.margin.right - settings.margin.labelMargin;
    
    var processedData = {
        nodes:[],
        links:[],
        totalGroup:0,
        groups:[]
    };
      var index = 1;
      _.each(dataObj, function(record, key){
          var node = {};
          node.name = key
            node.group = index;
            var newKey = key.split(" ").join("_");
            node.key = newKey;
            node.id = newKey;
            node.value = record;
            node.parentId = null;
            processedData.nodes.push(node);
            var color = visciraApp.chart.customColors(index);
            //console.log(' color ', color);
            node.color = color;
            var numberOfNodePerGroup = 1;
            if(record.children){
                _.each(record.children, function(child){
                    //console.log(child);
                    var childKey = child.name.split(" ").join("_");
                        childKey = childKey.split(".").join("");
                    var sourceKey = node.key; 
                    //console.log(' Source ', sourceKey);   
                    var link = {
                        source:sourceKey,
                        target:childKey,
                        value:child
                    }
                    //console.log(link);
                    var childNode = {};
                     childNode.key = childKey;
                     childNode.name = child.name;
                     childNode.id = childKey;
                     childNode.value = child;
                     childNode.group = index;
                     childNode.parentId = node.key;
                     childNode.color = color;
                     processedData.nodes.push(childNode);
                     processedData.links.push(link);
                     numberOfNodePerGroup++;
                });
            }
            var groupAndNode = {'id' : index, 'numberOfNodePerGroup' : numberOfNodePerGroup};
            processedData.groups.push(groupAndNode);

            index++;
        });
        processedData.totalGroup = index;
        console.log(processedData); 

        var svg = d3.select(element).append("svg")
                .attr("width",  svgWidth)
                .attr("height", svgHeight)    
                .attr("id", "main-chart")
                .attr("perserveAspectRatio","xMinYMin")
                .attr("viewBox","0 0 "+svgWidth+" "+ svgHeight);

         visciraApp.chart.plotPods(processedData, svgHeight, svgWidth, svg);
};
visciraApp.chart.plotPods = function( processedData, svgHeight, svgWidth, svg) {
          //Adding the g element for group .
        var podsPerGroupRow = 4;
        var gElementsCount = Math.ceil(processedData.totalGroup/podsPerGroupRow); //Per G element - 3 group .
        var groupHeight = Math.ceil(svgHeight / gElementsCount);
        var svgWidthXFactor = Math.ceil(svgWidth/podsPerGroupRow);
        var groupId = 1;

        var previousPodHeights = [0, 0];
        for(var i = 0; i < gElementsCount; i++){
            var groupElement = svg.append('g')
                                  .attr("id", "groupElement"+i);     
            //Addding rectangles to Group Element .
            groupHeight = 250;
            var svgWidthYFactor = i * groupHeight;

            for(var j = 1; j<= podsPerGroupRow; j++){
                var x, y, groupElementCounts;

                x = (j-1)*svgWidthXFactor; 

                if(i%2 == 0){
                  //x = (j-1)*svgWidthXFactor - 90;
                }else{
                  //x = (j-1)*svgWidthXFactor+100;
                }
               
                groupElementCounts = _.filter(processedData.groups, {id:groupId})[0];
                
                var podHeight = 0;
                var elementsPerGroup = 0;
                if(groupElementCounts){
                  elementsPerGroup = groupElementCounts.numberOfNodePerGroup;
                }
                if(elementsPerGroup < 3){
                    podHeight = 0;
                }else if(elementsPerGroup > 3 && elementsPerGroup < 10){
                    podHeight = 120;
                }else if(elementsPerGroup > 10){
                    podHeight = 140; 
                }
                previousPodHeights[j-1] = podHeight;
                //y = svgWidthYFactor + previousPodHeights[j-1];  
                y = svgWidthYFactor;          
              //Plotting Nodes per Group .
              var nodesGroup = _.filter(processedData.nodes, {group:groupId});
              //console.log(' nodesGroup ', nodesGroup);             
              var centerX = Math.ceil(x + svgWidthXFactor/2);
              var centerY = Math.ceil(y + groupHeight/2);
              var parentNode = _.filter(nodesGroup, {parentId:null})[0];
              //console.log(' parentNode ', parentNode); 
              //console.log('centerX '+centerX+' centerY '+centerY);
              var radius = 80;
              if(parentNode){
                parentNode.x = centerX;
                parentNode.y = centerY;
                
              }
              if(parentNode){
                var nodesGroupWithoutParent =  _.filter(nodesGroup, {parentId:parentNode.id});
                _.each(nodesGroupWithoutParent, function(node, i){
                    var elementsCount = nodesGroup.length-1;
                    var angle = (i / (elementsCount/2)) * Math.PI; 
                    var x1 = radius * Math.cos(angle); 
                    var y1 = radius * Math.sin(angle); 
                        x1 = x1+centerX;
                        y1 = y1+centerY;
                   //console.log(' x1 ' +  x1 +' y1 '+y1);
                    node.x = x1;
                    node.y = y1;
                    drawLine(groupElement, parentNode, node.color, node);
                    plotHexagoan(groupElement, x1, y1, 20, node.color, node);
                    
                });
                plotHexagoan(groupElement, centerX, centerY, 30, parentNode.color, parentNode);
              }
              groupId++; 

            } 
         } 
};


function plotHexagoan(groupElement, x, y, size, color, node){

        var div = d3.select("body").append("div") 
                  .attr("class", "tooltip")       
                  .style("opacity", 0);

        var _s32 = (Math.sqrt(3)/2);
        var A = size;
        var xDiff = x+10;
        var yDiff = y+2;
        var pointData = [[A+xDiff, 0+yDiff], [A/2+xDiff, A*_s32+yDiff], [-A/2+xDiff, A*_s32+yDiff], [-A+xDiff, 0+yDiff],
        [-A/2+xDiff, -A*_s32+yDiff], [A/2+xDiff, -A*_s32+yDiff]];
        //console.log(node);
        var text1 = '', text2 = '';
        text1 = node.name;
        if(!node.parentId){
          if(node.value.children.length){
            text2 = 'Links: '+node.value.children.length;
          }
        }else{
          text2 = 'Parent: '+node.parentId;
        }
        groupElement.selectAll("path.area")
                    .data([pointData]).enter().append("path")
                    .style("fill", color)
                    .on("mouseover", function(d) {
                        //console.log(node);
                        div.transition()    
                            .duration(200)    
                            .style("opacity", .9);    
                        div.html(text1+ "<br/>"  +text2)  
                            .style("left", (d3.event.pageX) + "px")   
                            .style("top", (d3.event.pageY - 10) + "px");  
                     })
                     .on("mouseout", function(d) {    
                        div.transition()    
                          .duration(500)    
                          .style("opacity", 0); 
                    })
                    .attr("d", d3.svg.line());
                  //Adding  test to Only parent Node. 
                  groupElement.append('text')
                        .attr("x", xDiff+15)
                        .attr("y", yDiff-15)
                        .text(function(){
                          if(!node.parentId){   
                            var label = '';                      
                            if(node.name.length > 10){
                              label =  node.name.substring(0, 12)+'...';
                            }else{
                              label =  node.name;
                            }
                            return label; 
                          }
                       })
                       .attr('class','parentName') 
                        .on("mouseover", function(d) {
                          //console.log(node);
                          div.transition()    
                            .duration(200)    
                            .style("opacity", .9);    
                          div.html(text1+ "<br/>"  +text2)  
                            .style("left", (d3.event.pageX) + "px")   
                            .style("top", (d3.event.pageY - 10) + "px");  
                     }).on("mouseout", function(d) {    
                          div.transition()    
                            .duration(500)    
                            .style("opacity", 0); 
                    });                     
}

function drawLine(groupElement, sourceNode, color, targetNode){

  var lineData = [{'x':sourceNode.x+10, 'y':sourceNode.y}, {'x':targetNode.x, 'y':targetNode.y}];
  var lineFunction = d3.svg.line()
                    .x(function(d) { return d.x; })
                    .y(function(d) { return d.y; })
                    .interpolate("monotone");
                    
                    groupElement.append("path")
                              .attr("d", lineFunction(lineData))
                              .attr("stroke", color)
                              .attr("stroke-width", 1)
                              .attr("fill", "none");
}

visciraApp.chart.customColors = function(index){
  var colors = ['#FF1493', '#9400D3', '#00BFFF', '#1E90FF', '#FF00FF', '#FF69B4', 
                '#9370DB', '#7B68EE', '#FF4500', '#4169E1', '#2E8B57', '#4682B4', 
                '#FF6347', '#9ACD32', '#B22222', '#483D8B', '#E9967A', '#FF8C00', 
                '#B8860B', '#00008B', '#8A2BE2', '#FF00FF', '#CD5C5C', '#778899', 
                '#9370DB', '#C71585', '#6B8E23', '#DA70D6', '#CD853F', '#FF0000', 
                '#00FF7F', '#9ACD32'];
  if(index<colors.length){
    return colors[index];   
  }else{
    return '#FF1493';
  }           

}